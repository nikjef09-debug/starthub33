# StartHub PATCH — Инструкция по применению

## Что входит в патч

### app.py (полная замена)
- **12 таблиц БД** вместо прежних 8:
  1. users (расширен: is_banned, ban_reason, last_seen, website, location)
  2. tags (глобальные теги)
  3. startups (расширен: team_size, founded_year, website, deals_count, is_verified)
  4. deals
  5. messages
  6. deal_documents
  7. news
  8. notifications ← НОВАЯ
  9. reviews ← НОВАЯ
  10. support_tickets ← НОВАЯ
  11. wallets ← НОВАЯ
  12. transactions ← НОВАЯ
  13. activity_logs ← НОВАЯ (итого 13 с ассоциативными)

### Новые роуты
- `/investors` — каталог инвесторов
- `/pricing` — страница тарифов
- `/contact` — контактная форма
- `/notifications` — уведомления пользователя
- `/wallet` — кошелёк + транзакции
- `/support` — тикеты поддержки
- `/review/startup/{id}` — оставить отзыв
- `/admin/analytics` — аналитика (только admin)
- `/admin/tickets` — тикеты (только admin)
- `/admin/reviews` — отзывы (только admin)
- `/admin/logs` — логи активности (только admin)
- `/admin/settings` — настройки (только admin)
- `/admin/users/{id}` — детальная страница пользователя (только admin)
- `/manager/dashboard` — панель менеджера
- `/manager/deals` — сделки (менеджер)
- `/manager/tickets` — тикеты (менеджер)
- `/manager/startups` — стартапы только просмотр (менеджер)
- `/manager/users` — пользователи только просмотр (менеджер)

### Разграничение admin / manager
| Функция               | Admin | Manager |
|-----------------------|-------|---------|
| Полная аналитика      | ✓     | ✕       |
| Бан пользователей     | ✓     | ✕       |
| Смена ролей           | ✓     | ✕       |
| Логи активности       | ✓     | ✕       |
| Настройки платформы   | ✓     | ✕       |
| Управление отзывами   | ✓     | ✕       |
| Просмотр всех сделок  | ✓     | ✓       |
| Ответы на тикеты      | ✓     | ✓       |
| Просмотр стартапов    | ✓     | ✓       |
| Просмотр пользователей| ✓     | ✓ (auth/buyer only) |

---

## Как применить

```bash
# 1. Замените app.py
cp patch/app.py ./app.py

# 2. Добавьте новые шаблоны
cp -r patch/templates/admin/* ./templates/admin/
cp -r patch/templates/manager ./templates/
cp -r patch/templates/user/notifications.html ./templates/user/
cp -r patch/templates/user/wallet.html ./templates/user/
cp -r patch/templates/user/support.html ./templates/user/
cp -r patch/templates/user/profile.html ./templates/user/
cp -r patch/templates/pages ./templates/

# 3. Добавьте CSS патч (в конец main.css или как отдельный файл)
cat patch/static/css/patch.css >> ./static/css/main.css

# 4. Удалите старую БД (схема изменилась)
rm -f starthub.db

# 5. Запустите
python app.py
```

## Тестовые аккаунты (создаются автоматически)
| Email                  | Пароль      | Роль    | Панель              |
|------------------------|-------------|---------|---------------------|
| admin@starthub.ru      | admin123    | admin   | /admin/dashboard    |
| manager@starthub.ru    | manager123  | manager | /manager/dashboard  |
| author@starthub.ru     | author123   | author  | /my-startups        |
| buyer@starthub.ru      | buyer123    | buyer   | /my-deals           |
