import os
import sys
import threading
import webbrowser
import time
import secrets
import enum
import re
import uuid
import bcrypt
import uvicorn
import multiprocessing
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional
from threading import Timer
from contextlib import asynccontextmanager
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType

# === ФИКС ДЛЯ СБОРКИ В EXE (исправляет ошибку AttributeError: 'NoneType' object has no attribute 'isatty') ===
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

# === ОПРЕДЕЛЕНИЕ ПУТЕЙ (внутри EXE и снаружи) ===
if getattr(sys, 'frozen', False):
    # Если запущено как EXE
    BASE_DIR = Path(sys._MEIPASS)
    EXE_DIR = Path(sys.executable).parent
else:
    # Если запущен просто .py
    BASE_DIR = Path(__file__).resolve().parent
    EXE_DIR = BASE_DIR

STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

# Путь к БД делаем РЯДОМ с .exe, чтобы данные сохранялись постоянно
DB_PATH = EXE_DIR / "starthub.db"
DATABASE_URL = f"sqlite+aiosqlite:///{DB_PATH}"

# Импорты FastAPI и прочего
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from fastapi import (
    Cookie, Depends, FastAPI, File, Form, HTTPException,
    Request, UploadFile, WebSocket, WebSocketDisconnect,
)
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from jose import JWTError, jwt
from passlib.context import CryptContext
from PIL import Image
from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, ForeignKey,
    Integer, String, Table, Text, select, func, or_, update, desc
)
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, relationship, selectinload

# ─── CONFIG ───────────────────────────────────────────────────────────────────
SECRET_KEY = os.getenv("SECRET_KEY", "starthub-super-secret-key-change-in-prod")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_DAYS = 30
UPLOAD_DIR = STATIC_DIR / "uploads"
MAX_IMAGE_SIZE = (1280, 720)
AVATAR_SIZE = (256, 256)

engine = create_async_engine(DATABASE_URL, echo=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
async_session_maker = None

# ─── EMAIL CONFIG ─────────────────────────────────────────────────────────────
EMAIL_USER = os.getenv("EMAIL_USER", "nikromanov1406@gmail.com")
EMAIL_PASS = os.getenv("EMAIL_PASS", "uvadevhflevvnrt")

mail_conf = ConnectionConfig(
    MAIL_USERNAME=EMAIL_USER,
    MAIL_PASSWORD=EMAIL_PASS,
    MAIL_FROM=EMAIL_USER,
    MAIL_FROM_NAME="StartHub",
    MAIL_PORT=587,
    MAIL_SERVER="smtp.gmail.com",
    MAIL_STARTTLS=True,
    MAIL_SSL_TLS=False,
    USE_CREDENTIALS=True,
)
fast_mail = FastMail(mail_conf)


class Base(DeclarativeBase):
    pass


# ══════════════════════════════════════════════════════════════════════════════
# ASSOCIATION TABLES (many-to-many)
# ══════════════════════════════════════════════════════════════════════════════

deal_managers = Table(
    "deal_managers", Base.metadata,
    Column("deal_id", ForeignKey("deals.id"), primary_key=True),
    Column("user_id", ForeignKey("users.id"), primary_key=True),
)

favorites = Table(
    "favorites", Base.metadata,
    Column("user_id", ForeignKey("users.id"), primary_key=True),
    Column("startup_id", ForeignKey("startups.id"), primary_key=True),
)

startup_tags_assoc = Table(
    "startup_tags_assoc", Base.metadata,
    Column("startup_id", ForeignKey("startups.id"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id"), primary_key=True),
)


# ══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ══════════════════════════════════════════════════════════════════════════════

class UserRole(str, enum.Enum):
    author = "author"
    buyer = "buyer"
    manager = "manager"
    admin = "admin"


class StartupStatus(str, enum.Enum):
    draft = "draft"
    active = "active"
    sold = "sold"
    archived = "archived"


class DealStatus(str, enum.Enum):
    pending = "pending"
    active = "active"
    documents = "documents"
    closed_ok = "closed_ok"
    closed_fail = "closed_fail"

class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"
    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    token      = Column(String(128), unique=True, nullable=False, index=True)
    is_used    = Column(Boolean, default=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")


class MessageType(str, enum.Enum):
    text = "text"
    system = "system"
    document = "document"


class NotifType(str, enum.Enum):
    deal_new = "deal_new"
    deal_status = "deal_status"
    message = "message"
    system = "system"
    review = "review"


class ReviewTarget(str, enum.Enum):
    startup = "startup"
    user = "user"


class TicketStatus(str, enum.Enum):
    open = "open"
    in_progress = "in_progress"
    closed = "closed"


class TicketPriority(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"


class WithdrawStatus(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"


# ══════════════════════════════════════════════════════════════════════════════
# MODELS  (12 tables total)
# ══════════════════════════════════════════════════════════════════════════════

# 1. Users
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(64), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.buyer, nullable=False)
    full_name = Column(String(128))
    avatar = Column(String(512))
    bio = Column(Text)
    phone = Column(String(32))
    telegram = Column(String(64))
    website = Column(String(256))
    location = Column(String(128))
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    ban_reason = Column(Text)
    last_seen = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    startups = relationship("Startup", back_populates="author", lazy="select")
    deals_as_buyer = relationship("Deal", back_populates="buyer", foreign_keys="Deal.buyer_id")
    messages = relationship("Message", back_populates="sender")
    favorite_startups = relationship("Startup", secondary=favorites, back_populates="favorited_by")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    reviews_given = relationship("Review", back_populates="author", foreign_keys="Review.author_id")
    reviews_received = relationship("Review", back_populates="target_user", foreign_keys="Review.target_user_id")
    tickets = relationship("SupportTicket", back_populates="user", foreign_keys="SupportTicket.user_id")
    wallet = relationship("Wallet", back_populates="user", uselist=False, cascade="all, delete-orphan")
    activity_logs = relationship("ActivityLog", back_populates="user", cascade="all, delete-orphan")


# 2. Tags
class Tag(Base):
    __tablename__ = "tags"
    id = Column(Integer, primary_key=True)
    name = Column(String(64), unique=True, nullable=False)
    slug = Column(String(64), unique=True, nullable=False)
    color = Column(String(16), default="#E85D26")
    startups = relationship("Startup", secondary=startup_tags_assoc, back_populates="tags")


# 3. Startups
class Startup(Base):
    __tablename__ = "startups"
    id = Column(Integer, primary_key=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String(256), nullable=False)
    slug = Column(String(256), unique=True, nullable=False, index=True)
    category = Column(String(64))
    stage = Column(String(64))
    tagline = Column(String(512))
    description = Column(Text)
    cover_image = Column(String(512))
    emoji = Column(String(8), default="🚀")
    price = Column(Float)
    revenue = Column(Float)
    valuation = Column(Float)
    team_size = Column(Integer)
    founded_year = Column(Integer)
    website = Column(String(256))
    pitch_deck_url = Column(String(512))
    status = Column(Enum(StartupStatus), default=StartupStatus.draft)
    is_featured = Column(Boolean, default=False)
    is_verified = Column(Boolean, default=False)
    views_count = Column(Integer, default=0)
    deals_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    author = relationship("User", back_populates="startups")
    deals = relationship("Deal", back_populates="startup")
    favorited_by = relationship("User", secondary=favorites, back_populates="favorite_startups")
    tags = relationship("Tag", secondary=startup_tags_assoc, back_populates="startups")
    reviews = relationship("Review", back_populates="startup", foreign_keys="Review.startup_id")


# 4. Deals
class Deal(Base):
    __tablename__ = "deals"
    id = Column(Integer, primary_key=True)
    startup_id = Column(Integer, ForeignKey("startups.id"), nullable=False, index=True)
    buyer_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    status = Column(Enum(DealStatus), default=DealStatus.pending)
    amount = Column(Float)
    final_amount = Column(Float)
    note = Column(Text)
    reject_reason = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = Column(DateTime, nullable=True)

    startup = relationship("Startup", back_populates="deals")
    buyer = relationship("User", back_populates="deals_as_buyer", foreign_keys=[buyer_id])
    managers = relationship("User", secondary=deal_managers)
    messages = relationship("Message", back_populates="deal", cascade="all, delete-orphan")
    documents = relationship("DealDocument", back_populates="deal", cascade="all, delete-orphan")


# 5. Messages
class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    deal_id = Column(Integer, ForeignKey("deals.id"), nullable=False, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    type = Column(Enum(MessageType), default=MessageType.text)
    body = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    edited_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    deal = relationship("Deal", back_populates="messages")
    sender = relationship("User", back_populates="messages")


# 6. Deal Documents
class DealDocument(Base):
    __tablename__ = "deal_documents"
    id = Column(Integer, primary_key=True)
    deal_id = Column(Integer, ForeignKey("deals.id"), nullable=False, index=True)
    uploader_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    filename = Column(String(256))
    filepath = Column(String(512))
    file_size = Column(Integer)
    mime_type = Column(String(128))
    is_signed = Column(Boolean, default=False)
    signed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    deal = relationship("Deal", back_populates="documents")
    uploader = relationship("User")


# 7. News / Blog
class NewsPost(Base):
    __tablename__ = "news"
    id = Column(Integer, primary_key=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    title = Column(String(512), nullable=False)
    slug = Column(String(512), unique=True, nullable=False)
    cover = Column(String(512))
    excerpt = Column(Text)
    body = Column(Text)
    category = Column(String(64))
    is_published = Column(Boolean, default=False)
    is_blog = Column(Boolean, default=False)
    views_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    author = relationship("User")


# 8. Notifications
class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    type = Column(Enum(NotifType), default=NotifType.system)
    title = Column(String(256), nullable=False)
    body = Column(Text)
    link = Column(String(512))
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")


# 9. Reviews
class Review(Base):
    __tablename__ = "reviews"
    id = Column(Integer, primary_key=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    target = Column(Enum(ReviewTarget), nullable=False)
    startup_id = Column(Integer, ForeignKey("startups.id"), nullable=True)
    target_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    deal_id = Column(Integer, ForeignKey("deals.id"), nullable=True)
    rating = Column(Integer, nullable=False)  # 1-5
    comment = Column(Text)
    is_visible = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    author = relationship("User", back_populates="reviews_given", foreign_keys=[author_id])
    startup = relationship("Startup", back_populates="reviews", foreign_keys=[startup_id])
    target_user = relationship("User", back_populates="reviews_received", foreign_keys=[target_user_id])


# 10. Support Tickets
class SupportTicket(Base):
    __tablename__ = "support_tickets"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    assigned_to = Column(Integer, ForeignKey("users.id"), nullable=True)
    subject = Column(String(256), nullable=False)
    body = Column(Text, nullable=False)
    status = Column(Enum(TicketStatus), default=TicketStatus.open)
    priority = Column(Enum(TicketPriority), default=TicketPriority.medium)
    manager_reply = Column(Text)
    replied_at = Column(DateTime, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="tickets", foreign_keys=[user_id])
    assignee = relationship("User", foreign_keys=[assigned_to])


# 11. Wallet & Transactions
class Wallet(Base):
    __tablename__ = "wallets"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    balance = Column(Float, default=0.0)
    reserved = Column(Float, default=0.0)
    total_deposited = Column(Float, default=0.0)
    total_withdrawn = Column(Float, default=0.0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="wallet")
    transactions = relationship("Transaction", back_populates="wallet", cascade="all, delete-orphan")


class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    wallet_id = Column(Integer, ForeignKey("wallets.id"), nullable=False, index=True)
    deal_id = Column(Integer, ForeignKey("deals.id"), nullable=True)
    type = Column(String(32))        # deposit / withdraw / fee / deal_payment
    amount = Column(Float, nullable=False)
    status = Column(Enum(WithdrawStatus), default=WithdrawStatus.pending)
    description = Column(String(512))
    created_at = Column(DateTime, default=datetime.utcnow)

    wallet = relationship("Wallet", back_populates="transactions")


# 12. Activity Log
class ActivityLog(Base):
    __tablename__ = "activity_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    action = Column(String(128), nullable=False)
    entity = Column(String(64))       # startup / deal / user / ticket
    entity_id = Column(Integer)
    detail = Column(Text)
    ip = Column(String(64))
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="activity_logs")


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    return text.strip('-')


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


async def get_db():
    async with async_session_maker() as session:
        yield session


async def get_current_user(request: Request, db: AsyncSession = Depends(get_db)) -> Optional[User]:
    token = request.cookies.get("access_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            return None
    except JWTError:
        return None
    result = await db.execute(select(User).where(User.id == int(user_id)))
    u = result.scalar_one_or_none()
    if u and not u.is_banned:
        # update last_seen silently
        u.last_seen = datetime.utcnow()
        await db.commit()
    return u


async def require_user(request: Request, db: AsyncSession = Depends(get_db)) -> User:
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=302, headers={"Location": "/login"})
    return user


async def require_admin(request: Request, db: AsyncSession = Depends(get_db)) -> User:
    user = await get_current_user(request, db)
    if not user or user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Только для администраторов")
    return user


async def require_manager_or_admin(request: Request, db: AsyncSession = Depends(get_db)) -> User:
    user = await get_current_user(request, db)
    if not user or user.role not in (UserRole.admin, UserRole.manager):
        raise HTTPException(status_code=403, detail="Доступ запрещён")
    return user


async def save_image(file: UploadFile, folder: str, size: tuple) -> str:
    import io
    ext = Path(file.filename).suffix.lower() or ".jpg"
    filename = f"{uuid.uuid4().hex}{ext}"
    dest = UPLOAD_DIR / folder / filename
    dest.parent.mkdir(parents=True, exist_ok=True)
    contents = await file.read()
    img = Image.open(io.BytesIO(contents)).convert("RGB")
    img.thumbnail(size, Image.LANCZOS)
    img.save(dest, quality=85, optimize=True)
    return f"/static/uploads/{folder}/{filename}"


async def create_notification(db: AsyncSession, user_id: int, type: NotifType, title: str, body: str = "", link: str = ""):
    notif = Notification(user_id=user_id, type=type, title=title, body=body, link=link)
    db.add(notif)


async def log_activity(db: AsyncSession, user_id: int, action: str, entity: str = "", entity_id: int = None, detail: str = "", ip: str = ""):
    log = ActivityLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id, detail=detail, ip=ip)
    db.add(log)


def fmt_money(value):
    if value is None:
        return "—"
    if value >= 1_000_000:
        return f"₽ {value/1_000_000:.1f} млн"
    if value >= 1_000:
        return f"₽ {value/1_000:.0f} тыс"
    return f"₽ {value:.0f}"


# ══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class ConnectionManager:
    def __init__(self):
        self.active: dict[int, list[WebSocket]] = {}

    async def connect(self, deal_id: int, ws: WebSocket):
        await ws.accept()
        self.active.setdefault(deal_id, []).append(ws)

    def disconnect(self, deal_id: int, ws: WebSocket):
        try:
            self.active.get(deal_id, []).remove(ws)
        except ValueError:
            pass

    async def broadcast(self, deal_id: int, data: dict):
        for ws in self.active.get(deal_id, []):
            try:
                await ws.send_json(data)
            except Exception:
                pass


ws_manager = ConnectionManager()


# ══════════════════════════════════════════════════════════════════════════════
# SEED DATA
# ══════════════════════════════════════════════════════════════════════════════

async def seed_db(db: AsyncSession):
    result = await db.execute(select(User).where(User.email == "admin@starthub.ru"))
    if result.scalar_one_or_none():
        return

    admin = User(email="admin@starthub.ru", username="admin",
                 hashed_password=hash_password("admin123"), role=UserRole.admin,
                 full_name="Главный Администратор", is_active=True, is_verified=True,
                 bio="Администратор платформы StartHub", location="Москва")
    author = User(email="author@starthub.ru", username="neuralflow",
                  hashed_password=hash_password("author123"), role=UserRole.author,
                  full_name="Михаил Романов", is_active=True, is_verified=True,
                  bio="Серийный предприниматель, 3 экзита.", location="Санкт-Петербург",
                  telegram="@mromanov")
    buyer = User(email="buyer@starthub.ru", username="investor_dm",
                 hashed_password=hash_password("buyer123"), role=UserRole.buyer,
                 full_name="Дмитрий Козлов", is_active=True, is_verified=True,
                 bio="Angel investor, 50+ портфельных компаний.", location="Москва",
                 telegram="@dkozlov")
    manager = User(email="manager@starthub.ru", username="manager_kate",
                   hashed_password=hash_password("manager123"), role=UserRole.manager,
                   full_name="Екатерина Смирнова", is_active=True, is_verified=True,
                   bio="Менеджер сделок, 5 лет опыта в M&A", location="Москва")

    db.add_all([admin, author, buyer, manager])
    await db.flush()

    # Wallets
    for u in [admin, author, buyer, manager]:
        w = Wallet(user_id=u.id, balance=0.0, total_deposited=0.0)
        db.add(w)

    # Tags
    tag_names = ["AI", "FinTech", "GreenTech", "B2B", "SaaS", "Blockchain", "Mobile", "EdTech"]
    tags = []
    for t in tag_names:
        tag = Tag(name=t, slug=slugify(t))
        db.add(tag)
        tags.append(tag)
    await db.flush()

    # Startups
    startups_data = [
        dict(title="NeuralFlow — автоматизация документов", category="AI / ML", stage="Series A",
             tagline="ИИ для юридических документов", emoji="🤖",
             description="Платформа автоматического заполнения и анализа юридических документов на базе LLM. Экономит до 80% времени юристов. 200+ корпоративных клиентов.",
             price=12_000_000, revenue=3_500_000, valuation=60_000_000, team_size=12, founded_year=2022,
             is_featured=True, status=StartupStatus.active),
        dict(title="EcoChain — углеродные токены", category="GreenTech", stage="Seed",
             tagline="Блокчейн для экологии", emoji="🌱",
             description="Блокчейн-решение для верификации и торговли углеродными кредитами. Партнёры: 12 корпораций из Fortune 500.",
             price=8_000_000, revenue=1_200_000, valuation=25_000_000, team_size=6, founded_year=2023,
             status=StartupStatus.active),
        dict(title="MedSync — телемедицина B2B", category="HealthTech", stage="Series B",
             tagline="Корпоративная телемедицина", emoji="💊",
             description="Платформа корпоративной телемедицины с интеграцией в HR-системы. 40+ корпоративных клиентов, NPS 72.",
             price=25_000_000, revenue=8_000_000, valuation=120_000_000, team_size=35, founded_year=2021,
             is_featured=True, status=StartupStatus.active),
        dict(title="FinPilot — AI финансовый советник", category="FinTech", stage="Pre-seed",
             tagline="Персональный CFO для МСБ", emoji="📊",
             description="ИИ-платформа финансового планирования для малого бизнеса. Beta: 500 компаний, churn 3%.",
             price=5_000_000, revenue=500_000, valuation=15_000_000, team_size=4, founded_year=2024,
             status=StartupStatus.active),
        dict(title="LogiBot — роботизация склада", category="Logistics", stage="Seed",
             tagline="Автономные складские роботы", emoji="🤖",
             description="Система управления автономными роботами для складской логистики. ROI клиентов: 180%. 3 пилота.",
             price=15_000_000, revenue=4_000_000, valuation=45_000_000, team_size=18, founded_year=2022,
             status=StartupStatus.active),
        dict(title="EduSpace — EdTech платформа", category="EdTech", stage="Series A",
             tagline="Адаптивное обучение 2.0", emoji="📚",
             description="Персонализированная платформа онлайн-обучения с адаптивными траекториями. 50k+ студентов, retention 68%.",
             price=18_000_000, revenue=6_000_000, valuation=80_000_000, team_size=22, founded_year=2021,
             status=StartupStatus.active),
    ]

    created_startups = []
    for s_data in startups_data:
        slug = slugify(s_data["title"]) + f"-{uuid.uuid4().hex[:6]}"
        startup = Startup(author_id=author.id, slug=slug, **s_data)
        db.add(startup)
        created_startups.append(startup)
    await db.flush()

    # Sample deal
    deal = Deal(startup_id=created_startups[0].id, buyer_id=buyer.id,
                status=DealStatus.active, amount=10_000_000,
                note="Заинтересован в серьёзных переговорах по NeuralFlow")
    db.add(deal)
    await db.flush()

    msg = Message(deal_id=deal.id, sender_id=None, type=MessageType.system,
                  body="Сделка создана. Покупатель: Дмитрий Козлов. Ожидаем подтверждения автора.")
    db.add(msg)

    # Sample ticket
    ticket = SupportTicket(user_id=buyer.id, subject="Как загрузить документы в сделку?",
                           body="Не могу найти кнопку загрузки документов в интерфейсе чата сделки.",
                           priority=TicketPriority.medium)
    db.add(ticket)

    # Sample notification
    notif = Notification(user_id=author.id, type=NotifType.deal_new,
                         title="Новая сделка по NeuralFlow",
                         body="Инвестор Дмитрий Козлов предложил ₽10 млн",
                         link=f"/deal/{deal.id}")
    db.add(notif)

    # Sample news
    news1 = NewsPost(author_id=admin.id, title="StartHub запустил новую версию платформы",
                     slug="starthub-v2-launch", is_published=True, is_blog=False,
                     excerpt="Мы выпустили масштабное обновление с новым интерфейсом чата и системой документооборота.",
                     body="Команда StartHub рада представить версию 2.0 платформы...")
    news2 = NewsPost(author_id=admin.id, title="Как привлечь инвестора за 30 дней",
                     slug="how-to-get-investor-30-days", is_published=True, is_blog=True,
                     excerpt="Делимся проверенными стратегиями и реальными кейсами наших пользователей.",
                     body="Привлечение инвестиций — это процесс, а не событие...")
    db.add_all([news1, news2])

    # Activity log sample
    log = ActivityLog(user_id=admin.id, action="platform_launch", entity="system",
                      detail="StartHub v2 launched")
    db.add(log)

    await db.commit()


# ══════════════════════════════════════════════════════════════════════════════
# LIFESPAN
# ══════════════════════════════════════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI):
    global async_session_maker
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with async_session_maker() as db:
        await seed_db(db)
    yield


# ══════════════════════════════════════════════════════════════════════════════
# APP
# ══════════════════════════════════════════════════════════════════════════════



BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))

STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

app = FastAPI(title="StartHub v2", lifespan=lifespan)

app.mount(
    "/static",
    StaticFiles(directory=str(STATIC_DIR)),
    name="static"
)

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
# Регистрируем функцию fmt_money как фильтр 'money' для HTML-шаблонов
templates.env.filters["money"] = fmt_money


def render(name, request, ctx):
    ctx["request"] = request
    return templates.TemplateResponse(name, ctx)


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse)
async def home(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    featured = (await db.execute(
        select(Startup).where(Startup.status == StartupStatus.active)
        .options(selectinload(Startup.author))
        .order_by(Startup.is_featured.desc(), Startup.created_at.desc()).limit(6)
    )).scalars().all()
    return render("index.html", request, {"user": user, "startups": featured})


@app.get("/catalog", response_class=HTMLResponse)
async def catalog(request: Request, db: AsyncSession = Depends(get_db),
                  q: str = "", category: str = "", stage: str = "", sort: str = "newest"):
    user = await get_current_user(request, db)
    query = select(Startup).where(Startup.status == StartupStatus.active).options(selectinload(Startup.author))
    if q:
        query = query.where(or_(Startup.title.ilike(f"%{q}%"), Startup.tagline.ilike(f"%{q}%")))
    if category:
        query = query.where(Startup.category == category)
    if stage:
        query = query.where(Startup.stage == stage)
    query = query.order_by(Startup.price.asc() if sort == "price_asc" else
                           Startup.price.desc() if sort == "price_desc" else
                           Startup.created_at.desc())
    startups = (await db.execute(query)).scalars().all()
    categories = ["AI / ML", "FinTech", "HealthTech", "GreenTech", "EdTech", "Logistics", "SaaS", "E-commerce"]
    stages = ["Pre-seed", "Seed", "Series A", "Series B", "Series C"]
    return render("catalog.html", request, {
        "user": user, "startups": startups, "categories": categories, "stages": stages,
        "q": q, "selected_cat": category, "selected_stage": stage, "sort": sort
    })


@app.get("/startup/{slug}", response_class=HTMLResponse)
async def startup_detail(slug: str, request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    result = await db.execute(
        select(Startup).where(Startup.slug == slug)
        .options(selectinload(Startup.author), selectinload(Startup.tags), selectinload(Startup.reviews).selectinload(Review.author))
    )
    startup = result.scalar_one_or_none()
    if not startup:
        raise HTTPException(404, "Стартап не найден")
    startup.views_count = (startup.views_count or 0) + 1
    await db.commit()
    is_favorited = False
    if user:
        fav = (await db.execute(select(favorites).where(
            favorites.c.user_id == user.id, favorites.c.startup_id == startup.id
        ))).first()
        is_favorited = fav is not None
    avg_rating = None
    if startup.reviews:
        avg_rating = round(sum(r.rating for r in startup.reviews if r.is_visible) / max(len([r for r in startup.reviews if r.is_visible]), 1), 1)
    return render("startup_detail.html", request, {
        "user": user, "startup": startup, "is_favorited": is_favorited, "avg_rating": avg_rating
    })


@app.get("/news", response_class=HTMLResponse)
async def news_list(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    posts = (await db.execute(
        select(NewsPost).where(NewsPost.is_published == True, NewsPost.is_blog == False)
        .order_by(NewsPost.created_at.desc())
    )).scalars().all()
    return render("news.html", request, {"user": user, "posts": posts})


@app.get("/blog", response_class=HTMLResponse)
async def blog_list(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    posts = (await db.execute(
        select(NewsPost).where(NewsPost.is_published == True, NewsPost.is_blog == True)
        .order_by(NewsPost.created_at.desc())
    )).scalars().all()
    return render("blog.html", request, {"user": user, "posts": posts})


@app.get("/faq", response_class=HTMLResponse)
async def faq(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("faq.html", request, {"user": user})


@app.get("/about", response_class=HTMLResponse)
async def about(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("about.html", request, {"user": user})


@app.get("/terms", response_class=HTMLResponse)
async def terms(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("terms.html", request, {"user": user})


# ── NEW PUBLIC: Investors page ─────────────────────────────────────────────
@app.get("/investors", response_class=HTMLResponse)
async def investors_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    investors = (await db.execute(
        select(User).where(User.role == UserRole.buyer, User.is_active == True)
        .order_by(User.created_at.desc()).limit(20)
    )).scalars().all()
    return render("pages/investors.html", request, {"user": user, "investors": investors})


# ── NEW PUBLIC: Pricing page ────────────────────────────────────────────────
@app.get("/pricing", response_class=HTMLResponse)
async def pricing_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("pages/pricing.html", request, {"user": user})


# ── NEW PUBLIC: Contact page ────────────────────────────────────────────────
@app.get("/contact", response_class=HTMLResponse)
async def contact_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("pages/contact.html", request, {"user": user, "sent": False})


@app.post("/contact")
async def contact_post(request: Request, db: AsyncSession = Depends(get_db),
                       name: str = Form(""), email: str = Form(""), message: str = Form("")):
    user = await get_current_user(request, db)
    return render("pages/contact.html", request, {"user": user, "sent": True})


# ══════════════════════════════════════════════════════════════════════════════
# AUTH ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if user:
        return RedirectResponse("/profile", 302)
    return render("auth/login.html", request, {"user": None, "error": None})


@app.post("/login")
async def login_post(request: Request, db: AsyncSession = Depends(get_db),
                     email: str = Form(...), password: str = Form(...)):
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    if not user or not verify_password(password, user.hashed_password):
        return render("auth/login.html", request, {"user": None, "error": "Неверный email или пароль"})
    if user.is_banned:
        return render("auth/login.html", request, {"user": None, "error": f"Аккаунт заблокирован: {user.ban_reason}"})
    token = create_access_token({"sub": str(user.id)})
    await log_activity(db, user.id, "login", "user", user.id, ip=request.client.host if request.client else "")
    await db.commit()
    response = RedirectResponse("/profile", status_code=302)
    response.set_cookie("access_token", token, httponly=True, max_age=60 * 60 * 24 * 30, samesite="lax")
    return response


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if user:
        return RedirectResponse("/profile", 302)
    return render("auth/register.html", request, {"user": None, "error": None})


@app.post("/register")
async def register_post(request: Request, db: AsyncSession = Depends(get_db),
                        email: str = Form(...), username: str = Form(...),
                        password: str = Form(...), full_name: str = Form(""), role: str = Form("buyer")):
    existing = (await db.execute(select(User).where(or_(User.email == email, User.username == username)))).scalar_one_or_none()
    if existing:
        return render("auth/register.html", request, {"user": None, "error": "Email или username уже занят"})
    if role not in ("author", "buyer"):
        role = "buyer"
    new_user = User(email=email, username=username, hashed_password=hash_password(password),
                    role=UserRole(role), full_name=full_name, is_active=True)
    db.add(new_user)
    await db.flush()
    wallet = Wallet(user_id=new_user.id)
    db.add(wallet)
    await log_activity(db, new_user.id, "register", "user", new_user.id)
    await db.commit()
    token = create_access_token({"sub": str(new_user.id)})
    response = RedirectResponse("/profile", status_code=302)
    response.set_cookie("access_token", token, httponly=True, max_age=60 * 60 * 24 * 30, samesite="lax")
    return response


@app.get("/logout")
async def logout():
    response = RedirectResponse("/", 302)
    response.delete_cookie("access_token")
    return response

# ══════════════════════════════════════════════════════════════════════════════
# Forgotpassword
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/forgot-password", response_class=HTMLResponse)
async def forgot_password(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    return render("auth/forgot_password.html", request, {
        "user": user, "sent": False, "error": None
    })


@app.post("/forgot-password")
async def forgot_password_post(
    request: Request,
    db: AsyncSession = Depends(get_db),
    email: str = Form(...)
):
    user = await get_current_user(request, db)

    # Проверяем есть ли такой email в БД
    result = await db.execute(select(User).where(User.email == email))
    target = result.scalar_one_or_none()

    if not target:
        # Не раскрываем что email не найден — показываем то же сообщение
        return render("auth/forgot_password.html", request, {
            "user": user, "sent": True, "error": None
        })

    # Генерируем токен
    token = secrets.token_urlsafe(48)
    expires = datetime.utcnow() + timedelta(hours=2)

    # Удаляем старые токены этого пользователя
    await db.execute(
        select(PasswordResetToken).where(PasswordResetToken.user_id == target.id)
    )
    # Сохраняем новый токен
    reset_token = PasswordResetToken(
        user_id=target.id,
        token=token,
        expires_at=expires
    )
    db.add(reset_token)
    await db.commit()

    # Ссылка для сброса
    reset_link = f"http://localhost:8000/reset-password/{token}"

    # Отправляем письмо
    try:
        message = MessageSchema(
            subject="Сброс пароля — StartHub",
            recipients=[email],
            body=f"""
            <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;padding:32px;background:#0D0C0B;color:#fff;border-radius:12px">
              <h2 style="color:#E85D26;margin-bottom:8px">StartHub</h2>
              <h3 style="margin-bottom:16px">Сброс пароля</h3>
              <p style="color:rgba(255,255,255,0.7);margin-bottom:24px">
                Вы запросили сброс пароля для аккаунта <strong>{email}</strong>.<br>
                Ссылка действительна 2 часа.
              </p>
              <a href="{reset_link}"
                 style="display:inline-block;background:#E85D26;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:600;font-size:15px">
                Сбросить пароль
              </a>
              <p style="color:rgba(255,255,255,0.4);font-size:13px;margin-top:24px">
                Если вы не запрашивали сброс — просто проигнорируйте это письмо.
              </p>
            </div>
            """,
            subtype=MessageType.html
        )
        await fast_mail.send_message(message) # Добавили подчеркивание
    except Exception as e:
        print(f"[EMAIL ERROR] {e}")
        # Даже если почта не отправилась — не показываем ошибку пользователю

    return render("auth/forgot_password.html", request, {
        "user": user, "sent": True, "error": None
    })


@app.get("/reset-password/{token}", response_class=HTMLResponse)
async def reset_password_page(
    token: str,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    user = await get_current_user(request, db)

    # Проверяем токен
    result = await db.execute(
        select(PasswordResetToken).where(
            PasswordResetToken.token == token,
            PasswordResetToken.is_used == False,
            PasswordResetToken.expires_at > datetime.utcnow()
        )
    )
    reset = result.scalar_one_or_none()

    if not reset:
        return render("auth/reset_password.html", request, {
            "user": user, "token": token,
            "error": "Ссылка недействительна или истекла. Запросите новую.",
            "success": False, "invalid": True
        })

    return render("auth/reset_password.html", request, {
        "user": user, "token": token,
        "error": None, "success": False, "invalid": False
    })


@app.post("/reset-password/{token}")
async def reset_password_post(
    token: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    password: str = Form(...),
    password2: str = Form(...)
):
    user = await get_current_user(request, db)

    if password != password2:
        return render("auth/reset_password.html", request, {
            "user": user, "token": token,
            "error": "Пароли не совпадают",
            "success": False, "invalid": False
        })

    if len(password) < 8:
        return render("auth/reset_password.html", request, {
            "user": user, "token": token,
            "error": "Пароль должен быть минимум 8 символов",
            "success": False, "invalid": False
        })

    # Проверяем токен
    result = await db.execute(
        select(PasswordResetToken).options(selectinload(PasswordResetToken.user)).where(
            PasswordResetToken.token == token,
            PasswordResetToken.is_used == False,
            PasswordResetToken.expires_at > datetime.utcnow()
        )
    )
    reset = result.scalar_one_or_none()

    if not reset:
        return render("auth/reset_password.html", request, {
            "user": user, "token": token,
            "error": "Ссылка недействительна или истекла.",
            "success": False, "invalid": True
        })

    # Меняем пароль
    reset.user.hashed_password = hash_password(password)
    reset.is_used = True
    await db.commit()

    return render("auth/reset_password.html", request, {
        "user": user, "token": token,
        "error": None, "success": True, "invalid": False
    })


# ══════════════════════════════════════════════════════════════════════════════
# USER CABINET
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/profile", response_class=HTMLResponse)
async def profile(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    # Load wallet
    wallet = (await db.execute(select(Wallet).where(Wallet.user_id == user.id))).scalar_one_or_none()
    # Recent activity
    activity = (await db.execute(
        select(ActivityLog).where(ActivityLog.user_id == user.id)
        .order_by(ActivityLog.created_at.desc()).limit(10)
    )).scalars().all()
    # Notifications count
    unread_notifs = (await db.execute(
        select(func.count(Notification.id)).where(Notification.user_id == user.id, Notification.is_read == False)
    )).scalar()
    # Deals count
    if user.role == UserRole.author:
        startup_ids = (await db.execute(select(Startup.id).where(Startup.author_id == user.id))).scalars().all()
        deals_count = (await db.execute(select(func.count(Deal.id)).where(Deal.startup_id.in_(startup_ids)))).scalar() if startup_ids else 0
        startups_count = len(startup_ids)
    else:
        deals_count = (await db.execute(select(func.count(Deal.id)).where(Deal.buyer_id == user.id))).scalar()
        startups_count = 0
    return render("user/profile.html", request, {
        "user": user, "wallet": wallet, "activity": activity,
        "unread_notifs": unread_notifs, "deals_count": deals_count, "startups_count": startups_count
    })


@app.post("/profile/update")
async def profile_update(request: Request, db: AsyncSession = Depends(get_db),
                         full_name: str = Form(""), bio: str = Form(""), phone: str = Form(""),
                         telegram: str = Form(""), website: str = Form(""), location: str = Form(""),
                         avatar: UploadFile = File(None)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    user.full_name = full_name
    user.bio = bio
    user.phone = phone
    user.telegram = telegram
    user.website = website
    user.location = location
    if avatar and avatar.filename:
        user.avatar = await save_image(avatar, "avatars", AVATAR_SIZE)
    await log_activity(db, user.id, "profile_update", "user", user.id)
    await db.commit()
    return RedirectResponse("/profile", 302)


# ── Notifications ─────────────────────────────────────────────────────────────
@app.get("/notifications", response_class=HTMLResponse)
async def notifications_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    notifs = (await db.execute(
        select(Notification).where(Notification.user_id == user.id)
        .order_by(Notification.created_at.desc()).limit(50)
    )).scalars().all()
    # Mark all as read
    await db.execute(
        update(Notification).where(Notification.user_id == user.id, Notification.is_read == False)
        .values(is_read=True)
    )
    await db.commit()
    return render("user/notifications.html", request, {"user": user, "notifications": notifs})


# ── Wallet ─────────────────────────────────────────────────────────────────────
@app.get("/wallet", response_class=HTMLResponse)
async def wallet_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    wallet = (await db.execute(
        select(Wallet).where(Wallet.user_id == user.id).options(selectinload(Wallet.transactions))
    )).scalar_one_or_none()
    return render("user/wallet.html", request, {"user": user, "wallet": wallet})


@app.post("/wallet/deposit")
async def wallet_deposit(request: Request, db: AsyncSession = Depends(get_db), amount: float = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    wallet = (await db.execute(select(Wallet).where(Wallet.user_id == user.id))).scalar_one_or_none()
    if wallet:
        wallet.balance += amount
        wallet.total_deposited += amount
        tx = Transaction(wallet_id=wallet.id, type="deposit", amount=amount,
                         status=WithdrawStatus.approved, description="Пополнение баланса")
        db.add(tx)
        await log_activity(db, user.id, "deposit", "wallet", wallet.id, detail=f"+{amount}")
    await db.commit()
    return RedirectResponse("/wallet", 302)


# ── Support Tickets ──────────────────────────────────────────────────────────
@app.get("/support", response_class=HTMLResponse)
async def support_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    tickets = (await db.execute(
        select(SupportTicket).where(SupportTicket.user_id == user.id)
        .order_by(SupportTicket.created_at.desc())
    )).scalars().all()
    return render("user/support.html", request, {"user": user, "tickets": tickets})


@app.post("/support/new")
async def support_new(request: Request, db: AsyncSession = Depends(get_db),
                      subject: str = Form(...), body: str = Form(...), priority: str = Form("medium")):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    ticket = SupportTicket(user_id=user.id, subject=subject, body=body,
                           priority=TicketPriority(priority))
    db.add(ticket)
    await log_activity(db, user.id, "ticket_created", "ticket", detail=subject)
    await db.commit()
    return RedirectResponse("/support", 302)


# ── My Startups ────────────────────────────────────────────────────────────────
@app.get("/my-startups", response_class=HTMLResponse)
async def my_startups(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    startups = (await db.execute(
        select(Startup).where(Startup.author_id == user.id).order_by(Startup.created_at.desc())
    )).scalars().all()
    return render("user/my_startups.html", request, {"user": user, "startups": startups})


@app.get("/my-startups/new", response_class=HTMLResponse)
async def new_startup_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    return render("user/startup_form.html", request, {"user": user, "startup": None, "error": None})


@app.post("/my-startups/new")
async def new_startup_post(request: Request, db: AsyncSession = Depends(get_db),
                           title: str = Form(...), category: str = Form(""), stage: str = Form(""),
                           tagline: str = Form(""), description: str = Form(""), emoji: str = Form("🚀"),
                           price: str = Form(""), revenue: str = Form(""), valuation: str = Form(""),
                           team_size: str = Form(""), founded_year: str = Form(""), website: str = Form(""),
                           cover: UploadFile = File(None)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    slug = f"{slugify(title)}-{uuid.uuid4().hex[:6]}"
    startup = Startup(author_id=user.id, title=title, slug=slug, category=category,
                      stage=stage, tagline=tagline, description=description, emoji=emoji or "🚀",
                      price=float(price) if price else None, revenue=float(revenue) if revenue else None,
                      valuation=float(valuation) if valuation else None,
                      team_size=int(team_size) if team_size else None,
                      founded_year=int(founded_year) if founded_year else None,
                      website=website, status=StartupStatus.active)
    if cover and cover.filename:
        startup.cover_image = await save_image(cover, "covers", MAX_IMAGE_SIZE)
    db.add(startup)
    await log_activity(db, user.id, "startup_created", "startup", detail=title)
    await db.commit()
    return RedirectResponse("/my-startups", 302)


@app.get("/my-startups/{startup_id}/edit", response_class=HTMLResponse)
async def edit_startup_page(startup_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if not startup or (startup.author_id != user.id and user.role != UserRole.admin):
        raise HTTPException(403)
    return render("user/startup_form.html", request, {"user": user, "startup": startup, "error": None})


@app.post("/my-startups/{startup_id}/edit")
async def edit_startup_post(startup_id: int, request: Request, db: AsyncSession = Depends(get_db),
                            title: str = Form(...), category: str = Form(""), stage: str = Form(""),
                            tagline: str = Form(""), description: str = Form(""), emoji: str = Form("🚀"),
                            price: str = Form(""), revenue: str = Form(""), valuation: str = Form(""),
                            team_size: str = Form(""), founded_year: str = Form(""), website: str = Form(""),
                            cover: UploadFile = File(None)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if not startup or (startup.author_id != user.id and user.role != UserRole.admin):
        raise HTTPException(403)
    startup.title = title; startup.category = category; startup.stage = stage
    startup.tagline = tagline; startup.description = description; startup.emoji = emoji or "🚀"
    startup.price = float(price) if price else None; startup.revenue = float(revenue) if revenue else None
    startup.valuation = float(valuation) if valuation else None
    startup.team_size = int(team_size) if team_size else None
    startup.founded_year = int(founded_year) if founded_year else None
    startup.website = website
    if cover and cover.filename:
        startup.cover_image = await save_image(cover, "covers", MAX_IMAGE_SIZE)
    await db.commit()
    return RedirectResponse("/my-startups", 302)


# ── My Deals ──────────────────────────────────────────────────────────────────
@app.get("/my-deals", response_class=HTMLResponse)
async def my_deals(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    if user.role == UserRole.author:
        startup_ids = (await db.execute(select(Startup.id).where(Startup.author_id == user.id))).scalars().all()
        deals = (await db.execute(
            select(Deal).where(Deal.startup_id.in_(startup_ids))
            .options(selectinload(Deal.startup), selectinload(Deal.buyer))
            .order_by(Deal.created_at.desc())
        )).scalars().all() if startup_ids else []
    elif user.role in (UserRole.manager, UserRole.admin):
        deals = (await db.execute(
            select(Deal).options(selectinload(Deal.startup), selectinload(Deal.buyer))
            .order_by(Deal.created_at.desc())
        )).scalars().all()
    else:
        deals = (await db.execute(
            select(Deal).where(Deal.buyer_id == user.id)
            .options(selectinload(Deal.startup), selectinload(Deal.buyer))
            .order_by(Deal.created_at.desc())
        )).scalars().all()
    return render("user/my_deals.html", request, {"user": user, "deals": deals})


# ── Favorites ─────────────────────────────────────────────────────────────────
@app.get("/favorites", response_class=HTMLResponse)
async def favorites_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    result = await db.execute(select(User).where(User.id == user.id).options(selectinload(User.favorite_startups)))
    user_with_favs = result.scalar_one()
    return render("user/favorites.html", request, {"user": user, "startups": user_with_favs.favorite_startups})


@app.post("/favorites/toggle/{startup_id}")
async def toggle_favorite(startup_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return JSONResponse({"error": "Не авторизован"}, 401)
    fav = (await db.execute(select(favorites).where(
        favorites.c.user_id == user.id, favorites.c.startup_id == startup_id
    ))).first()
    if fav:
        await db.execute(favorites.delete().where(
            favorites.c.user_id == user.id, favorites.c.startup_id == startup_id))
        is_fav = False
    else:
        await db.execute(favorites.insert().values(user_id=user.id, startup_id=startup_id))
        is_fav = True
    await db.commit()
    return JSONResponse({"favorited": is_fav})


# ── Reviews ────────────────────────────────────────────────────────────────────
@app.post("/review/startup/{startup_id}")
async def add_review(startup_id: int, request: Request, db: AsyncSession = Depends(get_db),
                     rating: int = Form(...), comment: str = Form("")):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if not startup:
        raise HTTPException(404)
    existing = (await db.execute(select(Review).where(
        Review.author_id == user.id, Review.startup_id == startup_id
    ))).scalar_one_or_none()
    if not existing:
        review = Review(author_id=user.id, target=ReviewTarget.startup,
                        startup_id=startup_id, rating=max(1, min(5, rating)), comment=comment)
        db.add(review)
        await db.commit()
    return RedirectResponse(f"/startup/{startup.slug}", 302)


# ══════════════════════════════════════════════════════════════════════════════
# DEAL ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/deal/create/{startup_id}")
async def create_deal(startup_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if not startup:
        raise HTTPException(404)
    existing = (await db.execute(select(Deal).where(
        Deal.startup_id == startup_id, Deal.buyer_id == user.id,
        Deal.status.in_([DealStatus.pending, DealStatus.active])
    ))).scalar_one_or_none()
    if existing:
        return RedirectResponse(f"/deal/{existing.id}", 302)
    form = await request.form()
    deal = Deal(startup_id=startup_id, buyer_id=user.id, status=DealStatus.pending,
                amount=float(form.get("amount", 0) or 0) or None, note=form.get("note", ""))
    db.add(deal)
    await db.flush()
    startup.deals_count = (startup.deals_count or 0) + 1
    sys_msg = Message(deal_id=deal.id, sender_id=None, type=MessageType.system,
                      body=f"Сделка создана. Покупатель: {user.full_name or user.username}. Ожидаем подтверждения.")
    db.add(sys_msg)
    await create_notification(db, startup.author_id, NotifType.deal_new,
                              f"Новая сделка по «{startup.title}»",
                              f"{user.full_name or user.username} предлагает {fmt_money(deal.amount) if deal.amount else 'сумму к обсуждению'}"
                              f"/deal/{deal.id}")
    await log_activity(db, user.id, "deal_created", "deal", deal.id, detail=startup.title)
    await db.commit()
    return RedirectResponse(f"/deal/{deal.id}", 302)


@app.get("/deal/{deal_id}", response_class=HTMLResponse)
async def deal_chat(deal_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", 302)
    deal = (await db.execute(
        select(Deal).where(Deal.id == deal_id)
        .options(selectinload(Deal.startup).selectinload(Startup.author),
                 selectinload(Deal.buyer), selectinload(Deal.managers),
                 selectinload(Deal.messages).selectinload(Message.sender),
                 selectinload(Deal.documents).selectinload(DealDocument.uploader))
    )).scalar_one_or_none()
    if not deal:
        raise HTTPException(404)
    is_author = deal.startup.author_id == user.id
    is_buyer = deal.buyer_id == user.id
    is_manager = user.role in (UserRole.manager, UserRole.admin)
    if not (is_author or is_buyer or is_manager):
        raise HTTPException(403)
    return render("deal/chat.html", request, {
        "user": user, "deal": deal, "is_author": is_author, "is_buyer": is_buyer, "is_manager": is_manager
    })


@app.post("/deal/{deal_id}/status")
async def update_deal_status(deal_id: int, request: Request, db: AsyncSession = Depends(get_db),
                              new_status: str = Form(...)):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(401)
    deal = (await db.execute(select(Deal).options(selectinload(Deal.startup)).where(Deal.id == deal_id))).scalar_one_or_none()
    if not deal:
        raise HTTPException(404)
    is_author = deal.startup.author_id == user.id
    is_manager = user.role in (UserRole.manager, UserRole.admin)
    if not (is_author or is_manager):
        raise HTTPException(403)
    deal.status = DealStatus(new_status)
    if new_status in ("closed_ok", "closed_fail"):
        deal.closed_at = datetime.utcnow()
    db.add(Message(deal_id=deal_id, sender_id=user.id, type=MessageType.system,
                   body=f"Статус изменён на «{new_status}» пользователем {user.full_name or user.username}."))
    await create_notification(db, deal.buyer_id, NotifType.deal_status,
                              f"Статус сделки изменён", f"Новый статус: {new_status}", f"/deal/{deal_id}")
    await log_activity(db, user.id, "deal_status_changed", "deal", deal_id, detail=new_status)
    await db.commit()
    return RedirectResponse(f"/deal/{deal_id}", 302)


@app.post("/deal/{deal_id}/upload-doc")
async def upload_document(
    deal_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    file: UploadFile = File(...),
):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(401, "Не авторизован")

    deal = (await db.execute(
        select(Deal)
        .options(selectinload(Deal.startup))
        .where(Deal.id == deal_id)
    )).scalar_one_or_none()

    if not deal:
        raise HTTPException(404, "Сделка не найдена")

    # ─── Проверка файла ─────────────────────────────────────────────
    if not file.filename:
        raise HTTPException(400, "Файл не выбран")

    ext = Path(file.filename).suffix.lower()

    allowed_ext = {".pdf", ".doc", ".docx", ".png", ".jpg", ".jpeg"}
    if ext not in allowed_ext:
        raise HTTPException(400, "Недопустимый тип файла")

    contents = await file.read()

    if not contents:
        raise HTTPException(400, "Пустой файл")

    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(400, "Файл слишком большой")

    # ─── Создание папки ─────────────────────────────────────────────
    upload_dir = UPLOAD_DIR / "docs"
    upload_dir.mkdir(parents=True, exist_ok=True)

    # ─── Генерация имени ────────────────────────────────────────────
    filename = f"{uuid.uuid4().hex}{ext}"
    dest = upload_dir / filename

    # ─── Сохранение файла ───────────────────────────────────────────
    try:
        dest.write_bytes(contents)
    except Exception:
        raise HTTPException(500, "Ошибка при сохранении файла")

    # ─── Сохранение в БД ────────────────────────────────────────────
    doc = DealDocument(
        deal_id=deal_id,
        uploader_id=user.id,
        filename=file.filename,
        filepath=f"/static/uploads/docs/{filename}",
        file_size=len(contents),
        mime_type=file.content_type,
    )
    db.add(doc)

    msg = Message(
        deal_id=deal_id,
        sender_id=user.id,
        type=MessageType.document,
        body=f"Загружен документ: {file.filename}",
    )
    db.add(msg)

    await db.commit()

    # ─── WebSocket уведомление ─────────────────────────────────────
    await ws_manager.broadcast(deal_id, {
        "type": "document",
        "sender": user.full_name or user.username,
        "body": f"📎 Загружен документ: {file.filename}",
        "time": datetime.utcnow().strftime("%H:%M"),
    })

    return RedirectResponse(f"/deal/{deal_id}", 302)


# ── WebSocket ──────────────────────────────────────────────────────────────────
@app.websocket("/ws/deal/{deal_id}")
async def deal_websocket(deal_id: int, ws: WebSocket):
    async with async_session_maker() as db:
        token = ws.query_params.get("token")
        user = None
        if token:
            try:
                payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
                user_id = payload.get("sub")
                result = await db.execute(select(User).where(User.id == int(user_id)))
                user = result.scalar_one_or_none()
            except Exception:
                pass
        if not user:
            await ws.close(code=1008)
            return
    await ws_manager.connect(deal_id, ws)
    try:
        while True:
            body = (await ws.receive_text()).strip()
            if not body:
                continue
            async with async_session_maker() as db:
                msg = Message(deal_id=deal_id, sender_id=user.id, type=MessageType.text, body=body)
                db.add(msg)
                await db.commit()
            await ws_manager.broadcast(deal_id, {
                "type": "message", "sender_id": user.id,
                "sender": user.full_name or user.username,
                "body": body, "time": datetime.utcnow().strftime("%H:%M")
            })
    except WebSocketDisconnect:
        ws_manager.disconnect(deal_id, ws)


# ══════════════════════════════════════════════════════════════════════════════
# ADMIN PANEL (admin only)
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    user_count = (await db.execute(select(func.count(User.id)))).scalar()
    startup_count = (await db.execute(select(func.count(Startup.id)))).scalar()
    deal_count = (await db.execute(select(func.count(Deal.id)))).scalar()
    active_deals = (await db.execute(select(func.count(Deal.id)).where(Deal.status == DealStatus.active))).scalar()
    ticket_count = (await db.execute(select(func.count(SupportTicket.id)).where(SupportTicket.status == TicketStatus.open))).scalar()
    revenue_total = (await db.execute(select(func.sum(Transaction.amount)).where(Transaction.type == "deposit", Transaction.status == WithdrawStatus.approved))).scalar() or 0
    recent_users = (await db.execute(select(User).order_by(User.created_at.desc()).limit(8))).scalars().all()
    recent_deals = (await db.execute(
        select(Deal).options(selectinload(Deal.startup), selectinload(Deal.buyer))
        .order_by(Deal.created_at.desc()).limit(8)
    )).scalars().all()
    recent_logs = (await db.execute(
        select(ActivityLog).options(selectinload(ActivityLog.user))
        .order_by(ActivityLog.created_at.desc()).limit(15)
    )).scalars().all()
    # Monthly stats (last 6 months fake distribution from db count)
    return render("admin/dashboard.html", request, {
        "user": user, "user_count": user_count, "startup_count": startup_count,
        "deal_count": deal_count, "active_deals": active_deals, "ticket_count": ticket_count,
        "revenue_total": revenue_total, "recent_users": recent_users,
        "recent_deals": recent_deals, "recent_logs": recent_logs
    })


@app.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, db: AsyncSession = Depends(get_db), q: str = "", role: str = ""):
    user = await require_admin(request, db)
    query = select(User).order_by(User.created_at.desc())
    if q:
        query = query.where(or_(User.email.ilike(f"%{q}%"), User.username.ilike(f"%{q}%"), User.full_name.ilike(f"%{q}%")))
    if role:
        query = query.where(User.role == UserRole(role))
    users = (await db.execute(query)).scalars().all()
    return render("admin/users.html", request, {"user": user, "users": users, "q": q, "role_filter": role})


@app.post("/admin/users/{user_id}/role")
async def admin_change_role(user_id: int, request: Request, db: AsyncSession = Depends(get_db), role: str = Form(...)):
    admin = await require_admin(request, db)
    target = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if target:
        target.role = UserRole(role)
        await log_activity(db, admin.id, "role_changed", "user", user_id, detail=f"→ {role}")
        await db.commit()
    return RedirectResponse("/admin/users", 302)


@app.post("/admin/users/{user_id}/ban")
async def admin_ban_user(user_id: int, request: Request, db: AsyncSession = Depends(get_db),
                          reason: str = Form("Нарушение правил")):
    admin = await require_admin(request, db)
    target = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if target and target.role != UserRole.admin:
        target.is_banned = not target.is_banned
        target.ban_reason = reason if target.is_banned else None
        await log_activity(db, admin.id, "user_ban" if target.is_banned else "user_unban", "user", user_id)
        await db.commit()
    return RedirectResponse("/admin/users", 302)


@app.get("/admin/users/{user_id}", response_class=HTMLResponse)
async def admin_user_detail(user_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    admin = await require_admin(request, db)
    target = (await db.execute(
        select(User).where(User.id == user_id)
        .options(selectinload(User.startups), selectinload(User.deals_as_buyer),
                 selectinload(User.activity_logs), selectinload(User.wallet))
    )).scalar_one_or_none()
    if not target:
        raise HTTPException(404)
    return render("admin/user_detail.html", request, {"user": admin, "target": target})


@app.get("/admin/startups", response_class=HTMLResponse)
async def admin_startups(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    startups = (await db.execute(
        select(Startup).options(selectinload(Startup.author)).order_by(Startup.created_at.desc())
    )).scalars().all()
    return render("admin/startups.html", request, {"user": user, "startups": startups})


@app.post("/admin/startups/{startup_id}/feature")
async def admin_feature_startup(startup_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    await require_admin(request, db)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if startup:
        startup.is_featured = not startup.is_featured
        await db.commit()
    return RedirectResponse("/admin/startups", 302)


@app.post("/admin/startups/{startup_id}/verify")
async def admin_verify_startup(startup_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    await require_admin(request, db)
    startup = (await db.execute(select(Startup).where(Startup.id == startup_id))).scalar_one_or_none()
    if startup:
        startup.is_verified = not startup.is_verified
        await db.commit()
    return RedirectResponse("/admin/startups", 302)


@app.get("/admin/deals", response_class=HTMLResponse)
async def admin_deals(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    deals = (await db.execute(
        select(Deal).options(selectinload(Deal.startup), selectinload(Deal.buyer))
        .order_by(Deal.created_at.desc())
    )).scalars().all()
    return render("admin/deals.html", request, {"user": user, "deals": deals})


@app.get("/admin/news", response_class=HTMLResponse)
async def admin_news(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    posts = (await db.execute(select(NewsPost).order_by(NewsPost.created_at.desc()))).scalars().all()
    return render("admin/news.html", request, {"user": user, "posts": posts})


@app.get("/admin/news/new", response_class=HTMLResponse)
async def admin_news_new(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    return render("admin/news_form.html", request, {"user": user, "post": None})


@app.post("/admin/news/new")
async def admin_news_create(request: Request, db: AsyncSession = Depends(get_db),
                             title: str = Form(...), body: str = Form(""), excerpt: str = Form(""),
                             is_blog: str = Form("0"), is_published: str = Form("0"), category: str = Form("")):
    user = await require_admin(request, db)
    slug = f"{slugify(title)}-{uuid.uuid4().hex[:6]}"
    post = NewsPost(author_id=user.id, title=title, slug=slug, body=body, excerpt=excerpt,
                    is_blog=is_blog == "1", is_published=is_published == "1", category=category)
    db.add(post)
    await db.commit()
    return RedirectResponse("/admin/news", 302)


@app.get("/admin/tickets", response_class=HTMLResponse)
async def admin_tickets(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    tickets = (await db.execute(
        select(SupportTicket).options(selectinload(SupportTicket.user))
        .order_by(SupportTicket.created_at.desc())
    )).scalars().all()
    return render("admin/tickets.html", request, {"user": user, "tickets": tickets})


@app.post("/admin/tickets/{ticket_id}/reply")
async def admin_ticket_reply(ticket_id: int, request: Request, db: AsyncSession = Depends(get_db),
                              reply: str = Form(...), status: str = Form("in_progress")):
    admin = await require_admin(request, db)
    ticket = (await db.execute(select(SupportTicket).where(SupportTicket.id == ticket_id))).scalar_one_or_none()
    if ticket:
        ticket.manager_reply = reply
        ticket.assigned_to = admin.id
        ticket.status = TicketStatus(status)
        ticket.replied_at = datetime.utcnow()
        if status == "closed":
            ticket.closed_at = datetime.utcnow()
        await create_notification(db, ticket.user_id, NotifType.system,
                                  "Ответ на ваш тикет", reply[:100], "/support")
        await db.commit()
    return RedirectResponse("/admin/tickets", 302)


@app.get("/admin/reviews", response_class=HTMLResponse)
async def admin_reviews(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    reviews = (await db.execute(
        select(Review).options(selectinload(Review.author), selectinload(Review.startup))
        .order_by(Review.created_at.desc())
    )).scalars().all()
    return render("admin/reviews.html", request, {"user": user, "reviews": reviews})


@app.post("/admin/reviews/{review_id}/toggle")
async def admin_toggle_review(review_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    await require_admin(request, db)
    review = (await db.execute(select(Review).where(Review.id == review_id))).scalar_one_or_none()
    if review:
        review.is_visible = not review.is_visible
        await db.commit()
    return RedirectResponse("/admin/reviews", 302)


@app.get("/admin/analytics", response_class=HTMLResponse)
async def admin_analytics(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    # Category breakdown
    cat_stats_raw = (await db.execute(
        select(Startup.category, func.count(Startup.id)).group_by(Startup.category)
    )).all()
    cat_stats = {r[0]: r[1] for r in cat_stats_raw if r[0]}
    # Deal status breakdown
    deal_stats_raw = (await db.execute(
        select(Deal.status, func.count(Deal.id)).group_by(Deal.status)
    )).all()
    deal_stats = {r[0].value: r[1] for r in deal_stats_raw}
    # User role breakdown
    role_stats_raw = (await db.execute(
        select(User.role, func.count(User.id)).group_by(User.role)
    )).all()
    role_stats = {r[0].value: r[1] for r in role_stats_raw}
    # Top startups by views
    top_startups = (await db.execute(
        select(Startup).options(selectinload(Startup.author))
        .order_by(Startup.views_count.desc()).limit(10)
    )).scalars().all()
    # Recent transactions
    recent_tx = (await db.execute(
        select(Transaction).order_by(Transaction.created_at.desc()).limit(20)
    )).scalars().all()
    return render("admin/analytics.html", request, {
        "user": user, "cat_stats": cat_stats, "deal_stats": deal_stats,
        "role_stats": role_stats, "top_startups": top_startups, "recent_tx": recent_tx
    })


@app.get("/admin/logs", response_class=HTMLResponse)
async def admin_logs(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    logs = (await db.execute(
        select(ActivityLog).options(selectinload(ActivityLog.user))
        .order_by(ActivityLog.created_at.desc()).limit(200)
    )).scalars().all()
    return render("admin/logs.html", request, {"user": user, "logs": logs})


@app.get("/admin/settings", response_class=HTMLResponse)
async def admin_settings(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_admin(request, db)
    return render("admin/settings.html", request, {"user": user})


# ══════════════════════════════════════════════════════════════════════════════
# MANAGER PANEL (manager only — limited scope)
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/manager/dashboard", response_class=HTMLResponse)
async def manager_dashboard(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_manager_or_admin(request, db)
    if user.role == UserRole.admin:
        return RedirectResponse("/admin/dashboard", 302)
    active_deals = (await db.execute(
        select(Deal).options(selectinload(Deal.startup), selectinload(Deal.buyer))
        .where(Deal.status.in_([DealStatus.pending, DealStatus.active, DealStatus.documents]))
        .order_by(Deal.created_at.desc()).limit(20)
    )).scalars().all()
    my_tickets = (await db.execute(
        select(SupportTicket).options(selectinload(SupportTicket.user))
        .where(or_(SupportTicket.assigned_to == user.id, SupportTicket.status == TicketStatus.open))
        .order_by(SupportTicket.created_at.desc()).limit(20)
    )).scalars().all()
    deal_count = len(active_deals)
    ticket_count = (await db.execute(
        select(func.count(SupportTicket.id)).where(SupportTicket.status == TicketStatus.open)
    )).scalar()
    return render("manager/dashboard.html", request, {
        "user": user, "active_deals": active_deals, "my_tickets": my_tickets,
        "deal_count": deal_count, "ticket_count": ticket_count
    })


@app.get("/manager/deals", response_class=HTMLResponse)
async def manager_deals(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_manager_or_admin(request, db)
    if user.role == UserRole.admin:
        return RedirectResponse("/admin/deals", 302)
    deals = (await db.execute(
        select(Deal).options(selectinload(Deal.startup), selectinload(Deal.buyer))
        .order_by(Deal.created_at.desc())
    )).scalars().all()
    return render("manager/deals.html", request, {"user": user, "deals": deals})


@app.get("/manager/tickets", response_class=HTMLResponse)
async def manager_tickets(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_manager_or_admin(request, db)
    if user.role == UserRole.admin:
        return RedirectResponse("/admin/tickets", 302)
    tickets = (await db.execute(
        select(SupportTicket).options(selectinload(SupportTicket.user))
        .order_by(SupportTicket.created_at.desc())
    )).scalars().all()
    return render("manager/tickets.html", request, {"user": user, "tickets": tickets})


@app.post("/manager/tickets/{ticket_id}/reply")
async def manager_ticket_reply(ticket_id: int, request: Request, db: AsyncSession = Depends(get_db),
                                reply: str = Form(...), status: str = Form("in_progress")):
    user = await require_manager_or_admin(request, db)
    ticket = (await db.execute(select(SupportTicket).where(SupportTicket.id == ticket_id))).scalar_one_or_none()
    if ticket:
        ticket.manager_reply = reply
        ticket.assigned_to = user.id
        ticket.status = TicketStatus(status)
        ticket.replied_at = datetime.utcnow()
        if status == "closed":
            ticket.closed_at = datetime.utcnow()
        await create_notification(db, ticket.user_id, NotifType.system,
                                  "Ответ на ваш тикет", reply[:100], "/support")
        await db.commit()
    return RedirectResponse("/manager/tickets", 302)


@app.get("/manager/startups", response_class=HTMLResponse)
async def manager_startups(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_manager_or_admin(request, db)
    if user.role == UserRole.admin:
        return RedirectResponse("/admin/startups", 302)
    startups = (await db.execute(
        select(Startup).options(selectinload(Startup.author))
        .where(Startup.status == StartupStatus.active)
        .order_by(Startup.created_at.desc())
    )).scalars().all()
    return render("manager/startups.html", request, {"user": user, "startups": startups})


@app.get("/manager/users", response_class=HTMLResponse)
async def manager_users(request: Request, db: AsyncSession = Depends(get_db)):
    user = await require_manager_or_admin(request, db)
    if user.role == UserRole.admin:
        return RedirectResponse("/admin/users", 302)
    # Managers can only view, not edit roles
    users = (await db.execute(
        select(User).where(User.role.in_([UserRole.author, UserRole.buyer]))
        .order_by(User.created_at.desc())
    )).scalars().all()
    return render("manager/users.html", request, {"user": user, "users": users})

def open_browser():
    time.sleep(2)
    webbrowser.open("http://127.0.0.1:8000")

threading.Thread(target=open_browser, daemon=True).start()

# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Это обязательная строка для корректной работы multiprocessing в EXE
    multiprocessing.freeze_support()

    # Запускаем открытие браузера через 2 секунды
    Timer(2.0, open_browser).start()

    # ВАЖНО: передаем объект 'app' напрямую, а НЕ строку "app:app"
    # Также отключаем 'reload', так как он не работает в EXE
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        log_level="info"
    )