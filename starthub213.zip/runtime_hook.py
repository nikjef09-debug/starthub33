import threading
import webbrowser
import time

def open_browser():
    time.sleep(2)  # ждём пока сервер поднимется
    webbrowser.open("http://127.0.0.1:8000")

threading.Thread(target=open_browser, daemon=True).start()